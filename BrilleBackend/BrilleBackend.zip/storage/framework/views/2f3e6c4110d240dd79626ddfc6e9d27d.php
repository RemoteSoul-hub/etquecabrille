<?php $__env->startSection('title'); ?>
    Confirmer un Compte
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
<div class="container" style="margin-top: 100px">
    <center>


        <h6 style="text-align: center"><?php echo e($user->userFname); ?> - <?php echo e($user->userLname); ?></h6>

        <?php $__currentLoopData = $useridentities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $identity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="/storage/Identities/<?php echo e($identity->identity); ?>" style="height: 500px;margin-bottom:20px" class="img-fluid" alt="Responsive image">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form action="/confirmeuser" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="d-block" style="margin-bottom: 20px;">
                <input type="hidden" name="idUser" value="<?php echo e($user->idUser); ?>">
                <textarea name="raison" id="" cols="30" rows="10" placeholder="En cas Ou refuser Un Compte Veuille Remplire pourqoi"></textarea>
                <div>
                    <button class="btn btn-success" name="response" value="accept">Accepter</button>
                    <button class="btn btn-danger" name="response" value="reject">Refuser</button>
                </div>
            </div>
        </form>
    </center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BrilleBackend\resources\views/admin/identityconfirm.blade.php ENDPATH**/ ?>