<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="container">
        <h1 style="margin-top:100px">
            DASHBOARD
        </h1>

        <h6 style="margin:20px 0px">Statistique</h6>

        <div class="d-flex card-contain">
            <div class="card mr-3" style="width: 18rem; margin-right:10px;">
                <div class="card-body">
                  <h5 class="card-title">Nombre Utulisateurs: <?php echo e($users); ?></h5>
                  <h6 class="card-subtitle mb-2 text-muted">Utilisateurs</h6>

                  <a href="/users" class="card-link">Utilisateurs</a>

                </div>
            </div>
            <div class="card" style="width: 18rem; margin-right:10px;">
                <div class="card-body">
                  <h5 class="card-title">Nombre Particulier: <?php echo e($particulier); ?></h5>
                  <h6 class="card-subtitle mb-2 text-muted">Particulier</h6>
                  <a href="/users" class="card-link">Utilisateurs</a>

                </div>
            </div>
            <div class="card" style="width: 18rem; margin-right:10px;">
                <div class="card-body">
                  <h5 class="card-title">Nombre Professionels:<?php echo e($professionel); ?></h5>
                  <h6 class="card-subtitle mb-2 text-muted">Professionels</h6>
                  <a href="/users" class="card-link">Utilisateurs</a>
                </div>
            </div>
            <div class="card" style="width: 18rem; margin-right:10px;">
                <div class="card-body">
                  <h5 class="card-title">Nombre Commnades:<?php echo e($commande); ?></h5>
                  <h6 class="card-subtitle mb-2 text-muted">Commandes</h6>

                  <a href="/orders" class="card-link">Commandes</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BrilleBackend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>