<!DOCTYPE html>
<html>
<head>
    <title>New Order Confirmation</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
        }
        .header {
            padding: 20px;
            background-color: #f8f8f8;
            border-bottom: 1px solid #ddd;
        }
        .content {
            padding: 30px 20px;
        }
        .footer {
            padding: 20px;
            background-color: #f8f8f8;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h2>New Brief</h2>
        </div>
        <div class="content">
            <p>From <?php echo e($user->userFname); ?> <?php echo e($user->userLname); ?>,</p>
            <p>Thank you for your order. Your order number is [Order Number].</p>
            <p>We will send you another email once your order has been shipped.</p>
            <p>If you have any questions, please don't hesitate to contact us.</p>
            <p>Best Regards,</p>
            <p>Your Company Name</p>
        </div>
        <div class="footer">
            <p>© 2023 Your Company Name. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BrilleBackend\resources\views/Mails/newbrief.blade.php ENDPATH**/ ?>